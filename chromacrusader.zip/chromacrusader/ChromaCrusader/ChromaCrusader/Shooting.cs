﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// shooting enemies will create enemyPrrojectile objects
/// Editors: Fisher Meddaugh, Eric Delmonico
/// </summary>
namespace ChromaCrusader
{
    class Shooting : Enemy
    {
        // The direction this shooty
        // enemy will shoot towards
        private Vector2 shootDirection;

        /// <summary>
        /// The direction this shooty
        /// enemy will shoot towards
        /// </summary>
        public Vector2 ShootDirection
        {
            get { return shootDirection; }
        }

        /// <summary>
        /// parameterized constructor that sends info back to the standard Enemy
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Shooting(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper, Vector2 shootDirection) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            this.shootDirection = shootDirection;
        }
        public override void Draw(SpriteBatch sb, Rectangle offset)
        {
            if (shootDirection.X > 0)
            {
                Rectangle applied = new Rectangle(Position.Location - offset.Location, Position.Size);
                sb.Draw(
                    Texture,                    // - The texture to draw
                    new Vector2(applied.X, applied.Y),                 // - The location to draw on the screen
                    new Rectangle(                  // - The "source" rectangle
                        0,    //   - This rectangle specifies
                        0 + 39 + 39 + 39 + 39,          //	   where "inside" the texture
                        39,            //     to get pixels (We don't want to
                        39),          //     draw the whole thing)
                    Color.White,                    // - The color
                    0,                              // - Rotation (none currently)
                    Vector2.Zero,                   // - Origin inside the image (top left)
                    1.0f,                           // - Scale (100% - no change)
                    SpriteEffects.FlipHorizontally,                     // - Can be used to flip the image
                    0);                             // - Layer depth (unused)
            }
            else
            {
                Rectangle applied = new Rectangle(Position.Location - offset.Location, Position.Size);
                sb.Draw(
                    Texture,                    // - The texture to draw
                    new Vector2(applied.X, applied.Y),                 // - The location to draw on the screen
                    new Rectangle(                  // - The "source" rectangle
                        0,    //   - This rectangle specifies
                        0 + 39 + 39 + 39 + 39,          //	   where "inside" the texture
                        39,            //     to get pixels (We don't want to
                        39),          //     draw the whole thing)
                    Color.White,                    // - The color
                    0,                              // - Rotation (none currently)
                    Vector2.Zero,                   // - Origin inside the image (top left)
                    1.0f,                           // - Scale (100% - no change)
                    SpriteEffects.None,                     // - Can be used to flip the image
                    0);                             // - Layer depth (unused)
            }
        }

    }
}
