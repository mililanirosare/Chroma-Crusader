﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
/// <summary>
/// Fixing this was pain
/// 
/// Editors: Fisher Meddaugh, Jasen Harper, Eric Delmonico, Mililani Rosare, Nicolas Jensen
/// </summary>

namespace ChromaCrusader
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private StateController stateController;
        private StateController playerController;
        private Player player;
        private KeyboardState kbState;

        //object of the PaintHelper Class, created when the map is loaded in
        private CollisionHelper collisionHelper;

        // Filler textures
        private Texture2D fillerPlayer;
        private Texture2D fillerPlatform;
        private Texture2D fillerEnemies;
        private Texture2D fillerHazard;
        private Texture2D fillerExit;
        private Texture2D fillerOpenExit;
        private Texture2D fillerGameOver;
        private Texture2D shootingEnemies;
        private Texture2D flyingEnemies;


        public SpriteFont arial16;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here            
            this.stateController = new StateController(this);
            playerController = new StateController(player);

            stateController.Initialize();

            // Creating this arbitrarily, needs to 
            // be finalized by someone later on
            this.collisionHelper = new CollisionHelper();
            kbState = new KeyboardState();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            // Loading in filler textures
            fillerPlatform = Content.Load<Texture2D>("platform");
            fillerPlayer = Content.Load<Texture2D>("player");
            fillerEnemies = Content.Load<Texture2D>("SpriteSheet");
            flyingEnemies = Content.Load<Texture2D>("SpriteSheet");
            shootingEnemies = Content.Load<Texture2D>("SpriteSheet");
            fillerHazard = Content.Load<Texture2D>("hazard");
            fillerExit = Content.Load<Texture2D>("exit");
            fillerOpenExit = Content.Load<Texture2D>("openExit");
            fillerGameOver = Content.Load<Texture2D>("gameOver");

            //loads in textures from the StateController class
            stateController.LoadContent(Content.Load<Texture2D>("Home"),
                                        Content.Load<Texture2D>("Layer 4"),
                                        Content.Load<Texture2D>("Layer 1"),
                                        Content.Load<Texture2D>("Layer 2"),
                                        Content.Load<Texture2D>("Layer 3"),
                                        Content.Load<Texture2D>("projectile"),
                                        Content.Load<Texture2D>("gameOver"),
                                        Content.Load<Texture2D>("ReturnMainMenuButton"),
                                        Content.Load<Texture2D>("Home"),
                                        Content.Load<Texture2D>("You Win Text"),
                                        Content.Load<Texture2D>("PlayAgain"),
                                        Content.Load<Texture2D>("Instructions"),
                                        Content.Load<Texture2D>("Next Level"),
                                        Content.Load<Texture2D>("Levels"),
                                        Content.Load<Texture2D>("Back"),
                                        collisionHelper,
                                        Content.Load<Texture2D>("SpriteSheet"),
                                        Content.Load<Texture2D>("levelSelectButton"),
                                        Content.Load<Texture2D>("white"));

            arial16 = Content.Load<SpriteFont>("arial16");

            // Level editor for testing
            LevelLoader.Load(fillerEnemies,
                             shootingEnemies,
                             flyingEnemies,
                             fillerPlayer,
                             fillerPlatform,
                             fillerHazard,
                             fillerExit,
                             fillerOpenExit,
                             fillerGameOver,
                             32,
                             collisionHelper,
                             AssignPlayer);

            System.Diagnostics.Debug.WriteLine(collisionHelper.NumPaintables);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here

            ////counts how many levels are beaten so far
            //int numBeaten = 0;
            //foreach(LevelSelectLevel level in LevelLoader.Levels)
            //{
            //    if(level.Beaten)
            //    {
            //        numBeaten++;
            //    }
            //}

            ////writes a file of just the number of levels beaten
            //BinaryWriter writer = new BinaryWriter(new FileStream("../../../../Data/LevelsBeaten.dat", FileMode.Create));
            //writer.Write(numBeaten);
            //writer.Close();
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            //gets the keyboard state to move the player
            kbState = Keyboard.GetState();
            this.stateController.updateGameStates();

            // Updating time between projectile launches
            this.stateController.CheckProjectileTimes(gameTime);

            //updates animations
            stateController.UpdateAnimation(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(stateController.Color);

            // TODO: Add your drawing code here
            spriteBatch.Begin();

            this.stateController.drawGameStates(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }

        /// <summary>
        /// assigns the player from the levelloader
        /// </summary>
        public void AssignPlayer(Player player)
        {
            this.player = player;
        }
    }
}
