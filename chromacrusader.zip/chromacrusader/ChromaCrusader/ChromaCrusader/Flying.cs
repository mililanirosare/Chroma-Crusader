﻿using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Flying enemies are visible with some movement in the air
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class Flying : Enemy
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard Enemy
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Flying(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor, collisionHelper)
        {

        }
        public override void Draw(SpriteBatch sb, Rectangle offset)
        {
            Rectangle applied = new Rectangle(Position.Location - offset.Location, Position.Size);
            sb.Draw(
                Texture,                    // - The texture to draw
                new Vector2 (applied.X, applied.Y),                 // - The location to draw on the screen
                new Rectangle(                  // - The "source" rectangle
                    0,    //   - This rectangle specifies
                    0 + 39 + 39 + 39,          //	   where "inside" the texture
                    39,            //     to get pixels (We don't want to
                    39),          //     draw the whole thing)
                Color.White,                    // - The color
                0,                              // - Rotation (none currently)
                Vector2.Zero,                   // - Origin inside the image (top left)
                1.0f,                           // - Scale (100% - no change)
                SpriteEffects.None,                     // - Can be used to flip the image
                0);                             // - Layer depth (unused)
        }
    }
}
