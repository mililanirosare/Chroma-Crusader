﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// player projectiles paint objects or enemies then are destroyed
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class PlayerProjectile : Projectile
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard Projectile
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public PlayerProjectile(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper, Vector2 velocity) : base(newTexture, newPosition, newColor, collisionHelper, velocity)
        {

        }

    }
}
