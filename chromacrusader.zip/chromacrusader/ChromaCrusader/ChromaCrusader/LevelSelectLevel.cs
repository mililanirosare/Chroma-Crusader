﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// class for a level in the game on the level select screen, if it's been beaten
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class LevelSelectLevel
    {
        private bool beaten;
        public bool Beaten
        {
            get { return beaten; }
        }
        private string fileName;
        public string FileName
        {
            get { return fileName; }
        }
        private string levelName;
        public  string LevelName
        {
            get { return levelName; }
        }

        /// <summary>
        /// bool will be false unless the file read in at the start said it's true
        /// </summary>
        /// <param name="beaten"></param>
        /// <param name="fileName"></param>
        public LevelSelectLevel(bool beaten, string fileName,string levelName)
        {
            this.beaten = beaten;
            this.fileName = fileName;
            this.levelName = levelName;
        }

        //sets the bool to true
        public void BeatLevel()
        {
            beaten = true;
        }
    }
}
