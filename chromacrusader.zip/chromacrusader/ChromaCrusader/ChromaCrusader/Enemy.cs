﻿using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// enemies will all kill the player upon collison
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class Enemy : GameObject
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard GameObject
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Enemy(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor,collisionHelper)
        {
            TouchPlayer += collisionHelper.KillPlayer;
            TouchBullet += collisionHelper.Deactivate;
        }
    }
}
