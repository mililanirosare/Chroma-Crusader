﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// hazards kill the player when touched, but can still be painted
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class Hazard : Environment
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard Environment
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Hazard(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            TouchPlayer += collisionHelper.KillPlayer;
        }
    }
}
