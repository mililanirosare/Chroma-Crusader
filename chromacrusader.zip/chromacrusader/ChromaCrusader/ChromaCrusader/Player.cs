﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// the player has full movement controlled by the... player.
/// Editors: Fisher Meddaugh, Mililani Rosare, Eric Delmonico
/// </summary>
namespace ChromaCrusader
{
    public class Player : GameObject
    {
        // Direction the player is 
        // facing left=-1, right=1
        private int direction;

        /// <summary>
        /// Whether the player is facing left (-1) or right (1)
        /// </summary>
        public int Direction
        {
            get { return direction; }
            set
            {
                if (value == -1 || value == 1)
                {
                    direction = value;
                }
            }
        }

        /// <summary>
        /// parameterized constructor that sends info back to the standard GameObject
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Player(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            TouchEnemyBullet += collisionHelper.Deactivate;
        }
    }
}
