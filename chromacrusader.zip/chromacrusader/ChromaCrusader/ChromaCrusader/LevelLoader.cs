﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System.IO;

// Editors: Eric Delmonico, Fisher Meddaugh
// This class loads in levels created by the level editor
//
// - Need to implement a REAL standard sprite dimension
// - Need to make the enemy types have unique sprites

namespace ChromaCrusader
{
    public enum TileType
    {
        Player = 0,
        LandEnemy = 1,
        FlyingEnemy = 2,
        ShootingEnemy = 3,
        Platform = 4,
        Hazard = 5,
        Nothing = 6,
        Exit = 7
    }

    //delegate for assigning value for the player
    delegate void AssignPlayerDelegate(Player player);

    //delegate for assigning value for the exit
    delegate void AssignExitDelegate(LevelExit exit);

    static class LevelLoader
    {
        // Fields
        private static CollisionHelper collisionHelper;

        // The sprites used in the game
        private static Texture2D enemyTexture;
        private static Texture2D shootingEnemyTexture;
        private static Texture2D flyingEnemyTexture;
        private static Texture2D playerTexture;
        private static Texture2D platformTexture;
        private static Texture2D hazardTexture;
        private static Texture2D exitTexture;
        private static Texture2D openExitTexture;

        // Eventually will hold all level names
        //private static IEnumerable<string> allLevels;
        //public static List<string> SELECTABLE_LEVELS => allLevels.ToList();

        //number of levels beaten before the game was loaded, and the list of levels in the game
        private static int completedLevels;
        private static List<LevelSelectLevel> levels;
        public static List<LevelSelectLevel> Levels
        {
            get { return levels; }
        }

        // Storing the player;
        private static Player player;

        //storing the level exit
        private static LevelExit exit;

        // The standard width/height of sprites
        private static int spriteDimension;

        // The array where the map is stored
        private static List<GameObject> map;

        // The lowest position of an object on the map
        private static int lowestPosition;

        // Stores all enemies with
        // shooting capabilities
        private static List<Shooting> shootingEnemies;

        private static List<Enemy> enemies;

        // Stores all enemies that can walk
        private static List<Land> walkingEnemies;

        // Width and Height of the map
        private static int mapWidth;
        private static int mapHeight;

        // Properties
        /// <summary>
        /// All the gameobjects in the map
        /// </summary>
        public static List<GameObject> Map
        {
            get { return map; }
        }

        /// <summary>
        /// The y position of the lowest object on the map
        /// </summary>
        public static int LowestPosition
        {
            get { return lowestPosition; }
            set { lowestPosition = value; }
        }

        public static List<Enemy> Enemies
        {
            get { return enemies; }
        }

        /// <summary>
        /// All shooting enemies in this level
        /// </summary>
        public static List<Shooting> ShootingEnemies
        {
            get { return shootingEnemies; }
        }

        /// <summary>
        /// all walking enemies in the level
        /// </summary>
        public static List<Land> WalkingEnemies
        {
            get { return walkingEnemies; }
        }

        /// <summary>
        /// The width of the map
        /// </summary>
        public static int MapWidth { get { return mapWidth; } }

        /// <summary>
        /// The height of the map
        /// </summary>
        public static int MapHeight { get { return mapHeight; } }

        // Constructor
        /// <summary>
        /// Creates a new level loader. Only need one for whole program.
        /// </summary>
        /// <param name="enemyTexture">the sprite for the enemies</param>
        /// <param name="playerTexture">the sprite for the player</param>
        /// <param name="platformTexture">the sprite for the platforms</param>
        /// <param name="hazardTexture">the sprite for the hazards</param>
        /// <param name="exitTexture">the sprite for the unopened level exit</param>
        /// <param name="openExitTexture">the sprite for the opened exit</param>
        /// <param name="spriteDimension">the standard dimension of this game's sprites</param>
        /// <param name="collisionHelper">the CollisionHelper used across the game</param>
        public static void Load(Texture2D _enemyTexture,
                                Texture2D _shootingEnemyTexture,
                                Texture2D _flyingEnemyTexture,
                                Texture2D _playerTexture,
                                Texture2D _platformTexture,
                                Texture2D _hazardTexture,
                                Texture2D _exitTexture,
                                Texture2D _openExitTexture,
                                Texture2D fillerGameOver,
                                int _spriteDimension,
                                CollisionHelper _collisionHelper,
                                AssignPlayerDelegate assignPlayer)
        {
            enemyTexture = _enemyTexture;
            flyingEnemyTexture = _flyingEnemyTexture;
            shootingEnemyTexture = _shootingEnemyTexture;
            playerTexture = _playerTexture;
            platformTexture = _platformTexture;
            hazardTexture = _hazardTexture;
            exitTexture = _exitTexture;
            openExitTexture = _openExitTexture;
            spriteDimension = _spriteDimension;
            collisionHelper = _collisionHelper;

            // Lowest map position will 
            // start impossibly high
            lowestPosition = -1;

            //assigns the player in game1 to the levelloader one
            assignPlayer(player);

            // Fetching all level names then cleaning up their finlenames
            List<string> levelNames = (from s in Directory.GetFiles("../../../../Data/", "*.level")
                                       select Path.GetFileNameWithoutExtension(s)).ToList();

            //loads in the number of levels beaten
            if (File.Exists("../../../../Data/LevelsBeaten.dat"))
            {
                BinaryReader reader = new BinaryReader(new FileStream("../../../../Data/LevelsBeaten.dat", FileMode.Open));
                completedLevels = reader.ReadInt32();
                reader.Close();
            }

            //creates each level in the game based on if it's been completed
            levels = new List<LevelSelectLevel>();
            for(int i=0;i<levelNames.Count;i++)
            {
                if (levelNames[i].Contains(","))
                {
                    levels.Add(new LevelSelectLevel(i < completedLevels, levelNames[i], levelNames[i].Split(',')[1]));
                }
                else
                {
                    levels.Add(new LevelSelectLevel(i < completedLevels, levelNames[i], levelNames[i]));
                }
            }
        }

        // Methods
        /// <summary>
        /// Loads in a new level
        /// </summary>
        /// <param name="levelName">the name of the level file, including the .level extension Ex. "filename.level"</param>
        /// <returns></returns>
        public static bool LoadLevel(string levelName, Color color, AssignPlayerDelegate assignPlayer, AssignExitDelegate assignExit)
        {
            string filename = "../../../../Data/" + levelName + ".level";

            // The return value, tells 
            // whether the load was
            // successful or not
            bool success = false;

            BinaryReader reader = null;
            FileStream fileStream = null;

            // initializing the map list
            // and shootingEnemies list
            map = new List<GameObject>();
            shootingEnemies = new List<Shooting>();
            walkingEnemies = new List<Land>();
            enemies = new List<Enemy>();

            try
            {
                // Attempting to open a new fileStream
                fileStream = new FileStream(filename, FileMode.Open);
                reader = new BinaryReader(fileStream);

                // Read in width and height
                // for the loop below this
                int w = reader.ReadByte();
                int h = reader.ReadByte();

                // Width and height of the
                // map that will be used for
                // camera controls
                mapWidth = w;
                mapHeight = h;

                // Looping through all data,
                // keeping only data that is
                // not a "nothing" TileType
                for (int i = 0; i < h; i++)
                {
                    for (int j = 0; j < w; j++)
                    {
                        int x = (int)reader.ReadByte();
                        switch (x)
                        {
                            case (int)TileType.Player:
                                player = new Player(playerTexture,                     // player's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   Color.White,                       // player's initial color
                                                   collisionHelper);
                                break;

                            case (int)TileType.LandEnemy:
                                map.Add(new Land(enemyTexture,                        // enemy's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   Color.White,                       // player's initial color
                                                   collisionHelper));
                                break;

                            case (int)TileType.FlyingEnemy:
                                map.Add(new Flying(flyingEnemyTexture,                      // enemy's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   Color.White,                       // player's initial color
                                                   collisionHelper));
                                break;

                            case (int)TileType.ShootingEnemy:
                                // Shooting at a 135 degree angle
                                // TODO: ShootDirection is read in as
                                // two bytes right after this gameobject
                                Vector2 shootDirection = new Vector2(reader.ReadSingle(), -reader.ReadSingle());
                                //Vector2 shootDirection = new Vector2(-0.3f, -1);
                                shootDirection.Normalize();
                                map.Add(new Shooting(shootingEnemyTexture,                    // enemy's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   Color.White,                       // player's initial color
                                                   collisionHelper,
                                                   shootDirection));                  // the direction the enemy shoots in
                                break;

                            case (int)TileType.Platform:
                                map.Add(new Platform(platformTexture,                 // platform's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   color,                             // default color for backdrop
                                                   collisionHelper));
                                break;

                            case (int)TileType.Hazard:
                                map.Add(new Hazard(hazardTexture,                     // hazard's sprite
                                                   new Rectangle(spriteDimension * j, // x
                                                                 spriteDimension * i, // y
                                                                 spriteDimension,     // width
                                                                 spriteDimension),    // height
                                                   color,                       // player's initial color
                                                   collisionHelper));
                                break;
                            case (int)TileType.Exit:
                                exit = (new LevelExit(exitTexture,                     // hazard's sprite
                                                      new Rectangle(spriteDimension * j, // x
                                                                    spriteDimension * i, // y
                                                                    spriteDimension,     // width
                                                                    spriteDimension),    // height
                                                      Color.White,                       // player's initial color
                                                      collisionHelper,
                                                      openExitTexture));
                                break;
                        }
                    }
                }
                //assigns the player to the collison helper and stateController
                assignPlayer(player);
                collisionHelper.AssignPlayer(player);

                collisionHelper.AssignExit(exit);
                assignExit(exit);
                // if there are GameObjects in
                // the map List, success = true
                if (map.Count > 0)
                {
                    success = true;
                }

                //resets the collision helper
                collisionHelper.ResetPaint();

                // taking care of paintables
                // and finding lowestPosition
                foreach (GameObject g in map)
                {
                    // If the position of this object
                    // is below the lowest position,
                    // set lowestPosition to it's y
                    if (g.Position.Y > lowestPosition)
                    {
                        lowestPosition = g.Position.Y + g.Texture.Height;
                    }

                    // If the enemy is a shooting enemy, add 
                    // a reference in the shootingEnemies list
                    if (g is Shooting)
                    {
                        shootingEnemies.Add((Shooting)g);
                    }

                    //if it's a walking enemy (Land) then add it to that list
                    if (g is Land)
                    {
                        walkingEnemies.Add((Land)g);
                    }

                    // if the new object is paintable,
                    // increment paintable
                    if (g is IPaintable)
                    {
                        collisionHelper.IncrementPaintables();
                    }
                }

                // Putting all the enemies into 
                // their own list so that they 
                // can be drawn on top
                enemies = (from g in map
                           where g is Enemy
                           select (Enemy)g).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                // if the reader was created successfully,
                // make sure to close it after all is done
                if (reader != null)
                {
                    reader.Close();
                }
            }

            return success;
        }
    }
}
