﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// GameObject Class will include default fields of position, image, and color. 
/// It is the parent of Enemy, Environment, Player, and Projectiles
/// Its constructor is parameterized to take a texture, rectangle, and color.
/// It contains Methods for Drawing the Object and checking collision with a different object.
/// 
/// Editors: Fisher Meddaugh, Eric Delmonico
/// </summary>
namespace ChromaCrusader
{
    public class GameObject
    {
        // Field for the position all objects will have, 
        // and attributes for each needed part of it
        private Rectangle position;

        // Property for the position Rectangle
        public Rectangle Position
        {
            get { return position; }
            set { position = value; }
        }


        //field for the texture of the object
        private Texture2D texture;

        //accessor for the texture of the object
        public Texture2D Texture
        {
            get { return texture; }
            protected set { texture = value; }
        }

        //field for the default color, gets reverted if hit
        private Color defaultColor;

        //accessor for the collisionhelper to set it
        public Color DefaultColor
        {
            get { return defaultColor; }
        }

        //field for the color, all will start white until painted
        private Color color;

        //accessor for anyone and modifier for just the children
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        //field for if this object is active or not
        private bool isActive;
        public bool IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }

        //events for when this object interacts with the player or the bullet
        public event CollisionDelegate TouchPlayer;
        public event CollisionDelegate TouchBullet;
        public event CollisionDelegate TouchEnemyBullet;


        /// <summary>
        /// parameterized constructor that sets the initial texture and position of the object
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public GameObject(Texture2D newTexture, Rectangle newPosition, Color newColor,CollisionHelper collisionHelper)
        {
            //sets them to the new values it took in
            texture = newTexture;
            position = newPosition;
            color = newColor;
            defaultColor = newColor;

            //sets default IsActive to true
            isActive = true;
        }


        /// <summary>
        /// Draws whatever object this is at the given position, with given texture, and in the given color
        /// Done as a virtual so that it may be changed by a child, but doesn't have to be
        /// </summary>
        /// <param name="sb"></param>
        public virtual void Draw(SpriteBatch sb)
        {
            //calls the draw using the texture, position, and color. Done through the spritebatch passd by Game1.Draw()
            sb.Draw(texture, position, color);
        }

        /// <summary>
        /// Draw with an offset
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="offset"></param>
        public virtual void Draw(SpriteBatch sb, Rectangle offset)
        {
            // Applying the offset
            Rectangle applied = new Rectangle(position.Location - offset.Location, position.Size);
            sb.Draw(texture, applied, color);
        }

        /// <summary>
        /// checks if this object is colliding with the object provided as the check
        /// Done as a virtual so that it may be changed by a child, but doesn't have to be
        /// </summary>
        /// <param name="check"></param>
        /// <returns></returns>
        public virtual bool CheckCollision(GameObject check)
        {
            if (this.isActive && check.IsActive)
            {
                //performs the collision check
                if (position.Intersects(check.Position))
                {
                    //checks which type it is, then calls the event unless it's empty
                    if (check is Player)
                    {
                        TouchPlayer?.Invoke(this);
                    }
                    else if (check is PlayerProjectile)
                    {
                        TouchBullet?.Invoke(this);
                        //sets the color if it's paintable, since it would require a different type of event to do
                        if (this is IPaintable)
                        {
                            this.color = check.Color;
                        }
                    }
                    else if (check is EnemyProjectile)
                    {
                        TouchEnemyBullet?.Invoke(this);
                    }
                    return true;
                }
                else
                {
                    //returns false if not colliding
                    return false;
                }
            }
            //if it's not active then it's always false
            else { return false; }
        }
    }
}
