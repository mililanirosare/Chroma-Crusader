﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
// Controls the states of all classes in the game
// A handler will be implemented for each instance of an object in the game (Each enemy in the game will have its own handler)
// 
// Editors: Jasen Harper, Eric Delmonico, Nicolas Jensen, Fisher Meddaugh, Mililani Rosare
namespace ChromaCrusader
{
    public enum ClickState
    {
        click,
        notClick
    }
    public enum GameMethodStates // Used to check if the handle methods are being called in the Draw or Update method in Game1
    {
        Update,
        Draw
    }
    public enum GameState // States for the game
    {
        Menu,
        LevelSelect,
        Game,
        GameOver,
        Win,
        Instructions
    }

    //enum player states
    public enum PlayerState
    {
        StandLeft,
        StandRight,
        WalkLeft,
        WalkRight,
        Jump,
        Fall,
        Peak
    }
    class StateController
    {
        #region Fields
        private Rectangle[] levelButtons;
        private Texture2D levelSelectButtonTexture;
        private Vector2[] levelNameSizes;
        private Point levelSelectDrawOffset;
        private int lowestButtonYPos;
        private int prevScrollOffset;
        //stores the current level so when you win you can set the level as beaten
        private LevelSelectLevel currentLevel;

        private Game1 game1;
        private Player player;
        private LevelExit exit;
        private Enemy enemy;
        private GameState gameState;

        // Player variables
        private PlayerState playerState;
        private Vector2 playerVelocity;     // Player's velocity vector
        private Vector2 playerPosition;     // Player's non-integer position
        private bool playerIsGrounded;      // Whether the player is on the ground

        //main menu textures
        private Texture2D Menu;
        private Texture2D buttonStart;
        private Texture2D buttonInstructions;
        private Texture2D buttonOptions;
        private Texture2D buttonExit;

        //game over menu textures
        private Texture2D GameOver;
        private Texture2D buttonGameOverMainMenu;
        private Texture2D buttonPlayAgain;

        //win menu textures
        private Texture2D Win;
        private Texture2D buttonYouWin;
        private Texture2D buttonNextLevel;

        //instructions menu textures
        private Texture2D Instructions;
        private Texture2D buttonBack;

        //levels menu texture
        private Texture2D Level;

        //main menu rectangle locations
        private Rectangle MenuLoc;
        private Rectangle buttonStartLoc;
        private Rectangle buttonInstructionsLoc;
        private Rectangle buttonOptionsLoc;
        private Rectangle buttonExitLoc;

        //game over menu rectangle location
        private Rectangle GameOverLoc;
        private Rectangle buttonGameOverMenuMainLoc;
        private Rectangle buttonPlayAgainLoc;

        //win menu rectangle location
        private Rectangle WinLoc;
        private Rectangle buttonYouWinLoc;
        private Rectangle buttonNextLevelLoc;

        //instructions menu rectangle location
        private Rectangle InstructionsLoc;
        private Rectangle buttonBackLoc;

        //level menu rectangle location
        private Rectangle LevelLoc;

        //main menu button colors TEMPORARY
        private Color buttonStartColor;
        private Color buttonInstructionsColor;
        private Color buttonOptionsColor;
        private Color buttonExitColor;

        //game over button color TEMPORARY
        private Color buttonMenuColor;
        private Color buttonPlayAgainColor;

        //win menu button color TEMPORARY
        private Color buttonYouWinColor;
        private Color buttonNextLevelColor;

        //instructions menu colors TEMPORARY
        private Color buttonBackColor;

        //menu console dimensions
        private int menuWidth;
        private int menuHeight;

        //mouse and keyboard states
        private MouseState mState;
        private MouseState prevMState;
        private KeyboardState kbState;
        private KeyboardState prevKbState;

        //color for everything, dark mode/light mode
        private Color color;

        // time in seconds since last projectile was launched,
        // as well as the fire rate in seconds per projectile
        private float player_timeSinceLastShot;
        private const float player_fireRate = 0.01f;

        // Time since the last enemy fired and
        // fire rate of the shooting enemies
        private float enemy_timeSinceLastShot;
        private const float enemy_fireRate = 0.6f;

        // Launch speed of the player and enemy projectiles
        private const float player_projectileSpeed = 17.5f;
        private const float enemy_projectileSpeed = 17.5f;

        // Projectile creation necessities
        private Texture2D projectileTexture;
        private CollisionHelper collisionHelper;

        // All the projectiles present in the scene
        private List<Projectile> projectiles;

        //spritesheet
        private Texture2D spriteSheet;

        //animation stuffs
        private int frame;              // The current animation frame
        private double timeCounter;     // The amount of time that has passed
        private double fps;             // The speed of the animation
        private double timePerFrame;    // The amount of time (in fractional seconds) per frame
        private int FrameCount;       // The number of frames in the animation 

        // Constants for animations
        private const int SpriteRectOffsetY = 0;     // How far down in the image are the frames?
        private const int SpriteRectHeight = 39;     // The height of a single frame
        private const int SpriteRectWidth = 39;      // The width of a single frame

        private const float dropTime = 0.15f; // Amount of time player drops through platforms for
        private float player_timeSinceDrop = 0f; // Amount of time that has passed sincle player dropped
        private bool dropping;

        private PlayerState previousPlayerState;

        private Rectangle drawOffset;
        private Vector2 SCREEN_CENTER;

        //all the stuff used for the "ammo" bar
        private Texture2D whiteTexture;
        private Rectangle ammoBar;
        private Rectangle ammoBarBackground;
        private List<Rectangle> ammoBorder;
        private const int ammoWidth = 100;
        private int ammoMax = 500;
        private int ammoAmount = 500;
        private int ammoCost = 20;
        private int ammoGain = 1;

        private Rectangle progressBar;
        private Rectangle progressBarBackground;
        private List<Rectangle> progressBarBorder;
        private const int progressBarWidth = 100;
        private int maxPaintables;
        private int currentPainted = 0;

        Random random;
        #endregion
        public Color Color
        {
            get { return color; }
        }

        ClickState CurClickState = ClickState.notClick;

        // Override for the Game1
        public StateController(Game1 game1)
        {
            this.gameState = new GameState();
            this.game1 = game1;
            this.gameState = GameState.Menu;

            // Player starts out facing right,
            // and at a velocity of zero, and
            // position will be set as soon as
            // the player is found, so start @0
            // player starts out not grounded,
            // that will be set upon collision
            playerState = PlayerState.StandRight;
            previousPlayerState = PlayerState.StandRight;
            playerVelocity = Vector2.Zero;
            playerPosition = Vector2.Zero;
            playerIsGrounded = false;

            // player will be able to shoot
            // as soon as the game starts up
            player_timeSinceLastShot = player_fireRate;

            // initializing the projectiles
            // list as a new empty list
            projectiles = new List<Projectile>();

            // Setting the center of the screen
            SCREEN_CENTER = new Vector2(game1.GraphicsDevice.Viewport.Width / 2, game1.GraphicsDevice.Viewport.Height / 2);

            // Player does not start out dropping
            dropping = false;

            levelSelectDrawOffset = new Point(0, 0);
            lowestButtonYPos = int.MinValue;
        }

        //loads content
        public void LoadContent(Texture2D Menu,
                                Texture2D buttonStart,
                                Texture2D buttonInstructions,
                                Texture2D buttonOptions,
                                Texture2D buttonExit, 
                                Texture2D projectileTexture, 
                                Texture2D GameOver, 
                                Texture2D buttonGameOverMainMenu, 
                                Texture2D Win, 
                                Texture2D buttonYouWin, 
                                Texture2D buttonPlayAgain, 
                                Texture2D Instructions,
                                Texture2D buttonNextLevel,
                                Texture2D Level,
                                Texture2D buttonBack,
                                CollisionHelper collisionHelper, 
                                Texture2D spriteSheet,
                                Texture2D levelSelectButtonTexture,
                                Texture2D white)
        {
            //main menu
            this.Menu = Menu;
            this.buttonStart = buttonStart;
            this.buttonInstructions = buttonInstructions;
            this.buttonOptions = buttonOptions;
            this.buttonExit = buttonExit;

            //game over
            this.GameOver = GameOver;
            this.buttonGameOverMainMenu = buttonGameOverMainMenu;
            this.buttonPlayAgain = buttonPlayAgain;

            //win
            this.Win = Win;
            this.buttonYouWin = buttonYouWin;
            this.buttonNextLevel = buttonNextLevel;

            //instructions
            this.Instructions = Instructions;
            this.buttonBack = buttonBack;

            //levels
            this.Level = Level;

            // Used to create new projectiles
            this.projectileTexture = projectileTexture;
            this.collisionHelper = collisionHelper;

            //spritesheet
            this.spriteSheet = spriteSheet;

            this.levelSelectButtonTexture = levelSelectButtonTexture;

            whiteTexture = white;
        }

        //initializes content
        public void Initialize()
        {
            //menu
            menuWidth = game1.GraphicsDevice.Viewport.Width;
            menuHeight = game1.GraphicsDevice.Viewport.Height;
            buttonOptionsColor = Color.White;
            buttonInstructionsColor = Color.White;
            buttonExitColor = Color.White;
            buttonStartColor = Color.White;
            MenuLoc = new Rectangle(menuWidth / 2 - menuWidth / 2, menuHeight / 2 - menuHeight / 2, menuWidth, menuHeight);
            buttonStartLoc = new Rectangle(menuWidth / 2 - menuWidth / 3,menuHeight / 12, (menuWidth * 2 / 3) + 37, menuHeight / 6);
            buttonInstructionsLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 3) + 10, (menuWidth * 2 / 3) + 37, menuHeight / 10);
            buttonOptionsLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 2) + 15, (menuWidth * 2 / 3) + 37, menuHeight / 10);
            buttonExitLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight * 3 / 4) - 19, (menuWidth * 2 / 3) + 40, (menuHeight / 10) - 8);

            //game over
            buttonMenuColor = Color.White;
            buttonExitColor = Color.White;
            GameOverLoc = new Rectangle(menuWidth / 2 - menuWidth / 2, menuHeight / 2 - menuHeight / 2, menuWidth, menuHeight);
            buttonGameOverMenuMainLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 3) + 10, (menuWidth * 2 / 3) + 37, menuHeight / 10);
            buttonExitLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight * 3 / 4) - 19, (menuWidth * 2 / 3) + 40, (menuHeight / 10) - 8);
            buttonPlayAgainLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 3) + 10, (menuWidth * 2 / 3) + 37, menuHeight / 10);

            //win 
            buttonYouWinColor = Color.White;
            buttonMenuColor = Color.White;
            buttonExitColor = Color.White;
            WinLoc = new Rectangle(menuWidth / 2 - menuWidth / 2, menuHeight / 2 - menuHeight / 2, menuWidth, menuHeight);
            buttonYouWinLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, menuHeight / 12, (menuWidth * 2 / 3) + 37, menuHeight / 6);
            buttonGameOverMenuMainLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 2) + 15, (menuWidth * 2 / 3) + 37, menuHeight / 10);
            buttonExitLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight * 3 / 4) - 19, (menuWidth * 2 / 3) + 40, (menuHeight / 10) - 8);
            buttonNextLevelLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight / 3) + 10, (menuWidth * 2 / 3) + 37, menuHeight / 10);

            //instructions
            InstructionsLoc = new Rectangle(menuWidth / 2 - menuWidth / 2, menuHeight / 2 - menuHeight / 2, menuWidth, menuHeight);
            buttonBackColor = Color.White;
            buttonBackLoc = new Rectangle(menuWidth / 2 - menuWidth / 3, (MenuLoc.Y + menuHeight * 3 / 4) +55, (menuWidth * 2 / 3) + 40, (menuHeight / 10) - 8);

            //levels 
            LevelLoc = new Rectangle(menuWidth / 2 - menuWidth / 2, menuHeight / 2 - menuHeight / 2, menuWidth, menuHeight);

            random = new Random();

            //dark mode setup
            color = Color.White;

            //animations
            fps = 10.0;
            timePerFrame = 1.0 / fps;

            //sets the rectangles and stuff for the shooting bar, ints are for easier editing
            int bordersize = 3; 
            int ammoHeight = 30;
            int progressBarHeight = 30;
            ammoBar = new Rectangle(bordersize, game1.GraphicsDevice.Viewport.Height - ammoHeight - bordersize, ammoWidth, ammoHeight);
            ammoBarBackground = new Rectangle(bordersize, game1.GraphicsDevice.Viewport.Height - ammoHeight - bordersize, ammoWidth, ammoHeight);
            ammoBorder = new List<Rectangle>();
            ammoBorder.Add(new Rectangle(0, game1.GraphicsDevice.Viewport.Height - ammoHeight - (2 * bordersize), (2 * bordersize) + ammoWidth, bordersize));
            ammoBorder.Add(new Rectangle(0, game1.GraphicsDevice.Viewport.Height - ammoHeight - (2 * bordersize), bordersize, (2 * bordersize) + ammoHeight));
            ammoBorder.Add(new Rectangle(0, game1.GraphicsDevice.Viewport.Height - bordersize, (2 * bordersize) + ammoWidth, bordersize));
            ammoBorder.Add(new Rectangle(bordersize + ammoWidth, game1.GraphicsDevice.Viewport.Height - ammoHeight - (2 * bordersize), bordersize, (2 * bordersize) + ammoHeight));

            progressBar = new Rectangle(game1.GraphicsDevice.Viewport.Width - (progressBarWidth + bordersize), bordersize, progressBarWidth, progressBarHeight);
            progressBarBackground = new Rectangle(game1.GraphicsDevice.Viewport.Width - (progressBarWidth + bordersize), bordersize, progressBarWidth, progressBarHeight);
            progressBarBorder = new List<Rectangle>();
            // top border
            progressBarBorder.Add(new Rectangle(progressBar.X - bordersize, progressBar.Y - bordersize, bordersize * 2 + progressBarWidth, bordersize));
            // bottom border
            progressBarBorder.Add(new Rectangle(progressBar.X - bordersize, progressBar.Bottom, bordersize * 2 + progressBarWidth, bordersize));
            // Left border
            progressBarBorder.Add(new Rectangle(progressBar.X - bordersize, progressBar.Y - bordersize, bordersize, bordersize * 2 + progressBarHeight));
            // Right border
            progressBarBorder.Add(new Rectangle(progressBar.Right, progressBar.Y - bordersize, bordersize, bordersize * 2 + progressBarHeight));
        }

        // Override for the Player or Enemy
        public StateController(GameObject gameObject)
        {
            if (gameObject is Player)
            {
                this.player = (Player)gameObject;
            }
            else if (gameObject is Enemy)
            {
                this.enemy = (Enemy)gameObject;
            }
        }

        // Handles for the update method
        public void updateGameStates()
        {
            //Updates the time it takes for frames to pass for animations
            timePerFrame = 1.0 / fps;
            //sets states for button checks
            prevMState = mState;
            prevKbState = kbState;
            mState = Mouse.GetState();
            kbState = Keyboard.GetState();

            //when buttons are checked, it looks for when you STOP clicking
            switch (gameState)
            {
                case GameState.Menu:
                    if(buttonStartLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonStartColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.LevelSelect;
                            }
                        }
                        else
                        {
                            buttonStartColor = Color.Cyan;
                        }
                    }
                    else if (buttonInstructionsLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonInstructionsColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Instructions;
                            }
                        }
                        else
                        {
                            buttonInstructionsColor = Color.Cyan;
                        }
                    }
                    else if (buttonOptionsLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonOptionsColor = Color.DarkCyan;
                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                //dark mode option
                                if (color == Color.White)
                                {
                                    color = new Color(25, 25, 25);
                                }
                                else
                                {
                                    color = Color.White;
                                }
                            }
                        }
                        else
                        {
                            // Change the highlight color depending on the background color
                            if (color == Color.White)
                            {
                                buttonOptionsColor = Color.Cyan;
                            }
                            else
                            {
                                buttonOptionsColor = new Color(Color.Cyan.R - 175, Color.Cyan.G - 175, Color.Cyan.B - 175);
                            }
                        }
                    }
                    else if (buttonExitLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonExitColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                game1.Exit();
                            }
                        }
                        else
                        {
                            buttonExitColor = Color.Cyan;
                        }
                    }
                    else
                    {
                        buttonExitColor = Color.White;
                        buttonInstructionsColor = Color.White;
                        buttonStartColor = Color.White;

                        // Change the color of the options button depending on if the background color has been changed
                        if (color == Color.White) // If the background is white
                        {
                            buttonOptionsColor = Color.White; // The button is white
                        }
                        else // If the background is dark grey
                        {
                            buttonOptionsColor = new Color(color.R + 25, color.G + 25, color.B + 25); // The button is dark grey
                        }
                    }
                    if (kbState.IsKeyDown(Keys.Enter))
                    {
                        gameState = GameState.LevelSelect;
                    }
                    break;
                case GameState.LevelSelect:
                    // If there are no buttons ready, make them
                    if (levelButtons == null)
                    {
                        levelButtons = new Rectangle[LevelLoader.Levels.Count];
                        int buttonWidth = 600;
                        int buttonHeight = 32;
                        int newLine = 0;

                        // i modifier literally modifies
                        // i, the loop control veriable
                        int iModifier = 0;
                        
                        // Center-aligns the buttons
                        int xOffset = game1.GraphicsDevice.Viewport.Width / 2 - buttonWidth / 2;
                        for (int i = 0; i < levelButtons.Length; i++)
                        {
                            levelButtons[i] = new Rectangle(xOffset,
                                                            buttonHeight * newLine + i * 5,
                                                            buttonWidth,
                                                            buttonHeight);
                            
                            levelButtons[i].Location = new Point(xOffset, buttonHeight * newLine + (i + 30) * 5);
                            newLine++;
                            iModifier += i - 1;

                            if (levelButtons[i].Bottom > lowestButtonYPos)
                                lowestButtonYPos = levelButtons[i].Bottom + 10;
                        }
                    }

                    if (lowestButtonYPos > game1.GraphicsDevice.Viewport.Height)
                    {
                        // Allowing scrolling through levels
                        if (mState.ScrollWheelValue > prevScrollOffset)
                        {
                            levelSelectDrawOffset.Y += 10;
                        }
                        if (mState.ScrollWheelValue < prevScrollOffset)
                        {
                            levelSelectDrawOffset.Y -= 10;
                        }

                        // Preventing scrolling up infinitely
                        if (levelSelectDrawOffset.Y > 0)
                        {
                            levelSelectDrawOffset.Y = 0;
                        }

                        // Locks scroll to the lowest button position, preventing infinite scrolling
                        if (levelSelectDrawOffset.Y - game1.GraphicsDevice.Viewport.Height < -lowestButtonYPos)
                        {
                            levelSelectDrawOffset.Y = game1.GraphicsDevice.Viewport.Height - lowestButtonYPos;
                        }
                    }

                    // Test if the player clicked a button
                    //bool for seeing if a level should be accessed
                    bool previous = true;
                    Rectangle temp;
                    for (int i = 0; i < levelButtons.Length; i++)
                    {
                        temp = new Rectangle(levelButtons[i].Location + levelSelectDrawOffset, levelButtons[i].Size);
                        if (mState.LeftButton == ButtonState.Pressed && temp.Contains(mState.Position) && previous == true)
                        {
                            gameState = GameState.Game;
                            // Loading in the test level
                            currentLevel = LevelLoader.Levels[i];
                            LevelLoader.LoadLevel(currentLevel.FileName, color, AssignPlayer, AssignExit);
                            //sets speed to 0 and player state to stand
                            playerVelocity = new Vector2(0, 0);
                            playerState = PlayerState.StandRight;
                            ammoAmount = ammoMax;
                            levelSelectDrawOffset = new Point(0, 0);
                        }
                        previous = LevelLoader.Levels[i].Beaten;
                    }

                    prevScrollOffset = mState.ScrollWheelValue;
                    break;
                case GameState.Game:
                    // Will probably need to call the player and enemy handleGameObjectStates() in here
                    // if the play is hit by an enemy

                    //WARNING: CHANGED THE ORDER OF THE CALLS, so that collisions happen after things move

                    //increases the player's ammo
                    if (ammoAmount < ammoMax)
                    {
                        ammoAmount += ammoGain;
                    }

                    //take care of the motion of ground enemies
                    foreach(Land enemy in LevelLoader.WalkingEnemies)
                    {
                        int moveSpeed = 2;
                        //point to check the spot the enemy will move to
                        Point checker;
                        if (enemy.Direction == -1)
                        {
                            checker = new Point(enemy.Position.X + (enemy.Direction * moveSpeed),
                                                      enemy.Position.Bottom + 1);
                        }
                        else
                        {
                            checker = new Point(enemy.Position.X + enemy.Position.Width + (enemy.Direction * moveSpeed),
                                                      enemy.Position.Bottom + 1);
                        }

                        //bool and a loop to check if it'll move off the platform
                        bool notTouching = true;
                        foreach(GameObject value in LevelLoader.Map)
                        {
                            if ((value is Environment || value is Platform || value is Hazard) && value.Position.Contains(checker))
                            {
                                notTouching = false;
                                break;
                            }
                        }
                        //if it's not touching any platforms then move it, if not then change its direction
                        if (!notTouching)
                        {
                            enemy.Position = new Rectangle(enemy.Position.X + (enemy.Direction * moveSpeed),
                                                           enemy.Position.Y,
                                                           enemy.Position.Width,
                                                           enemy.Position.Height);
                        }
                        else if (enemy.Direction == -1)
                        {
                            enemy.Direction = 1;
                        }
                        else if (enemy.Direction == 1)
                        {
                            enemy.Direction = -1;
                        }
                    }

                    // if the mouse is down and player_fireRate seconds 
                    // has gone by before shooting, allow them to shoot
                    if (player_timeSinceLastShot >= player_fireRate && mState.LeftButton == ButtonState.Pressed && ammoAmount >= ammoCost)
                    {
                        // Setting the launch direction to the 
                        // vector between the mouse and player
                        Point mouseToPlayer = mState.Position - new Point((int)SCREEN_CENTER.X, (int)SCREEN_CENTER.Y);
                        Vector2 launchDirection = new Vector2(mouseToPlayer.X, mouseToPlayer.Y);
                        launchDirection.Normalize();

                        //randomizes the color of the paint ball
                        for (int i = 0; i == 0;)
                        {
                            int r = random.Next(0, 256);
                            int g = random.Next(0, 256);
                            int b = random.Next(0, 256);
                            //only continues if it is bright enough but not too bright
                            if (150 < r + g + b && r + g + b < 650)
                            {
                                i++;
                                // Creating the projectile
                                projectiles.Add(new PlayerProjectile(projectileTexture,                                             // texture
                                                                     player.Position,                                               // position in the form of a rectangle
                                                                     new Color(r, g, b),                                                   // draw color
                                                                     collisionHelper,                                               // collision helper
                                                                     (launchDirection * player_projectileSpeed) + playerVelocity)); // Velocity
                            }
                        }

                        // Resetting the time since last shot
                        player_timeSinceLastShot = 0;

                        //lowers the player's ammo
                        ammoAmount -= ammoCost;
                    }

                    // If the enemies shots have recharged...
                    if (enemy_timeSinceLastShot >= enemy_fireRate)
                    {
                        // Loop through each shooting 
                        // enemy and fire projectiles
                        foreach (Shooting s in LevelLoader.ShootingEnemies)
                        {
                            // but only if the shooting 
                            // enemy is still alive
                            if (s.IsActive)
                            {
                                // Random addition to velocity vector
                                Vector2 directionModifier;
                                if (s.ShootDirection.X < 0)
                                    directionModifier = new Vector2(random.Next(-10, 0) / 10.0f, random.Next(0, 5) / 10.0f);
                                else
                                    directionModifier = new Vector2(random.Next(0, 10) / 10.0f, random.Next(0, 5) / 10.0f);

                                Vector2 directionWithModifier = s.ShootDirection + directionModifier;
                                directionWithModifier.Normalize();

                                // Projectiles position is offset so 
                                // that it doesn't collide with the enemy
                                Rectangle projPosition = new Rectangle(s.Position.X, s.Position.Y - s.Position.Height - 1, s.Position.Width, s.Position.Height);

                                // TODO: UNIQUE TEXTURE B/W THIS AND THE PLAYER PROJECTILES
                                projectiles.Add(new EnemyProjectile(projectileTexture,                          // projectile sprite 
                                                                    projPosition,                                 // initial position
                                                                    Color.Red,                                // draw color
                                                                    collisionHelper,
                                                                    directionWithModifier * enemy_projectileSpeed)); // velocity vector
                            }
                        }

                        // Resetting the time since last 
                        // shot because the enemies shot
                        enemy_timeSinceLastShot = 0;
                    }

                    // Taking care of all projectile movement/physics
                    DoProjectileMotion();

                    // Storing the amount
                    // of platforms the player
                    // is colliding with
                    byte platformCollisions = 0;
                    // Checking collisions of each
                    // object against the player
                    for (int i = 0; i < LevelLoader.Map.Count; i++)
                    {
                        // Storing the collider that is being checked
                        GameObject colliderToCheck = LevelLoader.Map[i];
                        if (colliderToCheck.CheckCollision(player) &&           // if colliding with player
                            colliderToCheck is Platform &&                      // and it's a platform
                            player.Position.Bottom <= colliderToCheck.Position.Bottom &&  // and the player is actually on it
                            playerState != PlayerState.Jump &&                  // and the player is not jumping
                            playerState != PlayerState.Peak &&                    // Or have not started falling
                            !dropping)
                        {
                            // Then the player is
                            // "on the ground"
                            platformCollisions++;
                            playerIsGrounded = true;
                            playerPosition.Y = colliderToCheck.Position.Y - player.Texture.Height + 1;
                        }
                        // IF the player's not on any platforms,
                        // the player is then on the ground
                        if (platformCollisions == 0)
                        {
                            //checks if the player above the bottom edge of screen
                            if (playerPosition.Y < LevelLoader.LowestPosition)
                            {
                                playerIsGrounded = false;
                            }
                            //player is below edge of screen- dead
                            else
                            {
                                player.IsActive = false;
                                break;
                            }
                           
                        }

                        //sets the size of the ammo bar
                        ammoBar = new Rectangle(ammoBar.Location.X, ammoBar.Location.Y, (ammoAmount * ammoWidth) / ammoMax, ammoBar.Height);
                        currentPainted = collisionHelper.NumPainted; 
                        maxPaintables = collisionHelper.NumPaintables;
                        progressBar = new Rectangle(progressBar.Location.X, progressBar.Location.Y, (int)((float)currentPainted/ maxPaintables * progressBarWidth), progressBar.Height);
                    }

                    updateGameObjectStates(GameMethodStates.Update);
                    
                    //if the player has been killed, game over
                    if (!player.IsActive)
                    {
                        gameState = GameState.GameOver;
                    }
                    else if(exit.CheckCollision(player))
                    {
                        gameState = GameState.Win;
                        //sets this level as beaten
                        currentLevel.BeatLevel();

                        //saves the game
                        //counts how many levels are beaten so far
                        int numBeaten = 0;
                        foreach (LevelSelectLevel level in LevelLoader.Levels)
                        {
                            if (level.Beaten)
                            {
                                numBeaten++;
                            }
                        }
                        //writes a file of just the number of levels beaten
                        BinaryWriter writer = new BinaryWriter(new FileStream("../../../../Data/LevelsBeaten.dat", FileMode.Create));
                        writer.Write(numBeaten);
                        writer.Close();
                    }
                    break;
                case GameState.GameOver:
                    //player can click return to main menu and  click exit game to close the exam
                    //gameState = GameState.Game;
                    // else if the player clicks exit to menu

                    if (buttonGameOverMenuMainLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonMenuColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Menu; 
                            }
                        }
                        else
                        {
                            buttonMenuColor = Color.Cyan;
                        }
                    }
                    else if (buttonExitLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonExitColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                game1.Exit();
                            }
                        }
                        else
                        {
                            buttonExitColor = Color.Cyan;
                        }
                    }
                    else if(buttonPlayAgainLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonPlayAgainColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Game;
                                LevelLoader.LoadLevel(currentLevel.FileName, color, AssignPlayer, AssignExit);
                                //sets speed to 0 and player state to stand
                                playerVelocity = new Vector2(0, 0);
                                playerState = PlayerState.StandRight;
                                ammoAmount = ammoMax;
                            }
                        }
                        else
                        {
                            buttonPlayAgainColor = Color.Cyan;
                        }
                    }
                    else
                    {
                        buttonMenuColor = Color.White;
                        buttonExitColor = Color.White;
                        buttonPlayAgainColor = Color.White;
                    }
                    // Clear the list of projectiles
                    projectiles.Clear();

                    break;
                case GameState.Win:
                    //player can click return to main menu and  click exit game to close the exam
                    //gameState = GameState.Game;
                    // else if the player clicks exit to menu

                    if (buttonGameOverMenuMainLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonMenuColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Menu;
                            }
                        }
                        else
                        {
                            buttonMenuColor = Color.Cyan;
                        }
                    }
                    else if (buttonExitLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonExitColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                game1.Exit();
                            }
                        }
                        else
                        {
                            buttonExitColor = Color.Cyan;
                        }
                    }
                    else if (buttonNextLevelLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonNextLevelColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Game;
                                //sets the current level to the next one if there are any more levels
                                if (LevelLoader.Levels.Count > LevelLoader.Levels.IndexOf(currentLevel) + 1)
                                {
                                    currentLevel = LevelLoader.Levels[LevelLoader.Levels.IndexOf(currentLevel) + 1];
                                }
                                LevelLoader.LoadLevel(currentLevel.FileName, color, AssignPlayer, AssignExit);
                                //sets speed to 0 and player state to stand
                                playerVelocity = new Vector2(0, 0);
                                playerState = PlayerState.StandRight;
                                ammoAmount = ammoMax;
                            }
                        }
                        else
                        {
                            buttonNextLevelColor = Color.Cyan;
                        }
                    }
                    else
                    {
                        buttonMenuColor = Color.White;
                        buttonExitColor = Color.White;
                        buttonNextLevelColor = Color.White;
                    }

                    // Clear the list of projectiles
                    projectiles.Clear();
                    break;
                case GameState.Instructions:
                    if (buttonBackLoc.Contains(mState.Position))
                    {
                        if (prevMState.LeftButton == ButtonState.Pressed)
                        {
                            buttonBackColor = Color.DarkCyan;

                            if (mState.LeftButton == ButtonState.Released)
                            {
                                //things that happen when clicked here
                                gameState = GameState.Menu;
                            }
                        }
                        else
                        {
                            buttonBackColor = Color.Cyan;
                        }
                    }
                    else
                    {
                        buttonBackColor = Color.White;

                    }
                    break;
            }
        }
        // Handles for the draw method
        public void drawGameStates(SpriteBatch spriteBatch)
        {
            switch (gameState)
            {
                case GameState.Menu:
                    // TODO: GET MENU GRAPHICS
                    game1.IsMouseVisible = true;
                    spriteBatch.Draw(Menu, MenuLoc, Color.White);
                    if (CurClickState == ClickState.click)
                    {
                        spriteBatch.Draw(buttonStart, buttonStartLoc, Color.Red);
                        spriteBatch.Draw(buttonInstructions, buttonInstructionsLoc, Color.Red);
                        spriteBatch.Draw(buttonOptions, buttonOptionsLoc, Color.Red);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, Color.Red);
                    }
                    else
                    {
                        spriteBatch.Draw(buttonStart, buttonStartLoc, buttonStartColor);
                        spriteBatch.Draw(buttonInstructions, buttonInstructionsLoc, buttonInstructionsColor);
                        spriteBatch.Draw(buttonOptions, buttonOptionsLoc, buttonOptionsColor);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, buttonExitColor);
                    }
                    break;
                case GameState.LevelSelect:
                    spriteBatch.Draw(Level, LevelLoc, Color.White);
                    if (levelButtons != null)
                    {
                        // Getting the size of each level's name
                        if (levelNameSizes == null)
                        {
                            levelNameSizes = new Vector2[levelButtons.Length];
                            for (int i = 0; i < LevelLoader.Levels.Count; i++)
                            {
                                levelNameSizes[i] = game1.arial16.MeasureString(LevelLoader.Levels[i].LevelName);
                            }
                        }

                        // Drawing all the buttons
                        //bool for if the previous level was beaten
                        bool previous = true;
                        for (int i = 0; i < levelButtons.Length; i++)
                        {
                            // Changing color depending on 
                            // light mode or dark mode
                            Color buttonColor;
                            Color textColor;
                            //sets it to a green box ifit's beaten itself
                            if (LevelLoader.Levels[i].Beaten)
                            {
                                buttonColor = Color.Green;
                                textColor = Color.Black;
                            }
                            //sets it to light cyan if the previous level is beaten and thus this one is the next level
                            else if (previous)
                            {
                                buttonColor = Color.LightCyan;
                                textColor = Color.Black;
                            }
                            //gray it out if it's unaccessible
                            else
                            {
                                buttonColor = Color.DarkGray;
                                textColor = Color.Black;
                            }

                            Rectangle temp2 = new Rectangle(levelButtons[i].Location + levelSelectDrawOffset, levelButtons[i].Size);
                            spriteBatch.Draw(levelSelectButtonTexture, temp2, buttonColor);
                            Vector2 textPosition = new Vector2(levelButtons[i].Location.X + levelButtons[i].Size.X / 2 - levelNameSizes[i].X / 2, 
                                                               levelButtons[i].Location.Y + levelButtons[i].Size.Y / 2 - levelNameSizes[i].Y / 2);
                            
                            spriteBatch.DrawString(game1.arial16, 
                                                   LevelLoader.Levels[i].LevelName, 
                                                   new Vector2(textPosition.X + levelSelectDrawOffset.X, 
                                                   textPosition.Y + levelSelectDrawOffset.Y), 
                                                   textColor);
                            //sets the bool for this one's to the previous
                            previous = LevelLoader.Levels[i].Beaten;
                        }
                    }
                    break;
                case GameState.Game:
                    game1.IsMouseVisible = true;

                    // Calculating the draw offset
                    int screenH = game1.GraphicsDevice.Viewport.Height;
                    int screenW = game1.GraphicsDevice.Viewport.Width;
                    drawOffset = new Rectangle(player.Position.X - screenW / 2, // the x offset
                                                     player.Position.Y - screenH / 2, // the y offset
                                                     0, 0); // width and height

                    // Drawing all objects in the map
                    foreach (GameObject g in LevelLoader.Map)
                    {
                        if (g.IsActive && !(g is Enemy))
                        {

                            g.Draw(spriteBatch, drawOffset);
                        }
                    }

                    //draws level exit
                    exit.Draw(spriteBatch, drawOffset);
                    foreach (Enemy e in LevelLoader.Enemies)
                    {
                        if (e.IsActive)
                        {
                            e.Draw(spriteBatch, drawOffset);
                        }
                    }
                    foreach(Projectile p in projectiles)
                    {
                        p.Draw(spriteBatch, drawOffset);
                    }
                    //draws the shooting bar
                    spriteBatch.Draw(whiteTexture, ammoBarBackground, Color.White);
                    spriteBatch.Draw(whiteTexture, ammoBar, Color.Red);
                    foreach(Rectangle b in ammoBorder)
                    {
                        spriteBatch.Draw(whiteTexture, b, Color.Black);
                    }
                    //draws the progress bar
                    spriteBatch.Draw(whiteTexture, progressBarBackground, Color.White);
                    spriteBatch.Draw(whiteTexture, progressBar, Color.Cyan);
                    foreach (Rectangle b in progressBarBorder)
                    {
                        spriteBatch.Draw(whiteTexture, b, Color.Black);
                    }
                    string paintableInfo = $"Painted blocks: {currentPainted} / {maxPaintables}";
                    spriteBatch.DrawString(game1.arial16, 
                                           $"Painted blocks: {currentPainted} / {maxPaintables}", 
                                           new Vector2(progressBarBackground.Right - game1.arial16.MeasureString(paintableInfo).X + 3, 
                                                       progressBarBackground.Bottom + 3), 
                                           Color.Cyan);

                    //draws player
                    //player.Draw(spriteBatch);
                    switch (playerState)
                    {
                        case PlayerState.WalkRight:
                            fps = 10;
                            FrameCount = 2;
                            DrawSpriteWalking(SpriteEffects.FlipHorizontally, spriteBatch);
                            break;
                        case PlayerState.WalkLeft:
                            fps = 10;
                            FrameCount = 2;
                            DrawSpriteWalking(SpriteEffects.None, spriteBatch);
                            break;
                        case PlayerState.StandRight:
                            fps = 10;
                            FrameCount = 4;
                            DrawSpriteIdle(SpriteEffects.FlipHorizontally, spriteBatch);
                            break;
                        case PlayerState.StandLeft:
                            fps = 10;
                            FrameCount = 4;
                            DrawSpriteIdle(SpriteEffects.None, spriteBatch);
                            break;
                        case PlayerState.Jump:
                            fps = 6;
                            FrameCount = 2;
                            if (player.Direction == 1)
                            {
                                DrawSpriteJumping(SpriteEffects.FlipHorizontally, spriteBatch);
                            }
                            else
                            {
                                DrawSpriteJumping(SpriteEffects.None, spriteBatch);
                            }
                            //player.Draw(spriteBatch);
                            break;
                        case PlayerState.Fall:
                            fps = 10;
                            if (player.Direction == 1)
                            {
                                DrawSpriteFalling(SpriteEffects.FlipHorizontally, spriteBatch);
                            }
                            else
                            {
                                DrawSpriteFalling(SpriteEffects.None, spriteBatch);
                            }
                            //player.Draw(spriteBatch);
                            break;
                        case PlayerState.Peak:
                            fps = 10;
                            if (player.Direction == 1)
                            {
                                DrawSpriteFalling(SpriteEffects.FlipHorizontally, spriteBatch);
                            }
                            else
                            {
                                DrawSpriteFalling(SpriteEffects.None, spriteBatch);
                            }
                            //player.Draw(spriteBatch);
                            break;
                    }
                    // TODO: GET GAMEPLAY GRAPHICS (Score, other UI elements)
                    break;
                case GameState.GameOver:
                    game1.IsMouseVisible = true;
                    // TODO: GET GAME OVER SCREEN GRAPHICS

                    spriteBatch.Draw(GameOver, GameOverLoc, Color.White);
                    if (CurClickState == ClickState.click)
                    {
                        spriteBatch.Draw(buttonGameOverMainMenu, buttonGameOverMenuMainLoc, Color.Red);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, Color.Red);
                        spriteBatch.Draw(buttonPlayAgain, buttonPlayAgainLoc, Color.Red);
                    }
                    else
                    {
                        spriteBatch.Draw(buttonGameOverMainMenu, buttonGameOverMenuMainLoc, buttonMenuColor);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, buttonExitColor);
                        spriteBatch.Draw(buttonPlayAgain, buttonPlayAgainLoc, buttonPlayAgainColor);
                    }
                    break;
                case GameState.Win:
                    game1.IsMouseVisible = true;
                    // TODO: GET GAME WIN SCREEN GRAPHICS

                    spriteBatch.Draw(Win, WinLoc, Color.White);
                    if (CurClickState == ClickState.click)
                    {
                        spriteBatch.Draw(buttonGameOverMainMenu, buttonGameOverMenuMainLoc, Color.Red);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, Color.Red);
                        spriteBatch.Draw(buttonNextLevel, buttonNextLevelLoc, Color.Red);
                    }
                    else
                    {
                        spriteBatch.Draw(buttonYouWin, buttonYouWinLoc, buttonYouWinColor);
                        spriteBatch.Draw(buttonGameOverMainMenu, buttonGameOverMenuMainLoc, buttonMenuColor);
                        spriteBatch.Draw(buttonExit, buttonExitLoc, buttonExitColor);
                        spriteBatch.Draw(buttonNextLevel, buttonNextLevelLoc, buttonNextLevelColor);
                    }
                    break;
                case GameState.Instructions:
                    game1.IsMouseVisible = true;
                    spriteBatch.Draw(Instructions, InstructionsLoc, Color.White);
                    if (CurClickState == ClickState.click)
                    {
                        spriteBatch.Draw(buttonBack, buttonBackLoc, Color.Red);
                    }
                    else
                    {
                        spriteBatch.Draw(buttonBack, buttonBackLoc, buttonBackColor);
                    }
                    break;
            }
        }

        //draws the sprites walking animation
        private void DrawSpriteWalking(SpriteEffects flipSprite, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                spriteSheet,                    // - The texture to draw
                SCREEN_CENTER,                 // - The location to draw on the screen
                new Rectangle(                  // - The "source" rectangle
                    frame * SpriteRectWidth,    //   - This rectangle specifies
                    SpriteRectOffsetY,          //	   where "inside" the texture
                    SpriteRectWidth,            //     to get pixels (We don't want to
                    SpriteRectHeight),          //     draw the whole thing)
                Color.White,                    // - The color
                0,                              // - Rotation (none currently)
                Vector2.Zero,                   // - Origin inside the image (top left)
                1.0f,                           // - Scale (100% - no change)
                flipSprite,                     // - Can be used to flip the image
                0);                             // - Layer depth (unused)
        }

        //draws sprite jumping
        private void DrawSpriteJumping(SpriteEffects flipSprite, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                spriteSheet,                    // - The texture to draw
                SCREEN_CENTER,                 // - The location to draw on the screen
                new Rectangle(                  // - The "source" rectangle
                    frame * SpriteRectWidth,    //   - This rectangle specifies
                    SpriteRectOffsetY + SpriteRectHeight + SpriteRectHeight,          //	   where "inside" the texture
                    SpriteRectWidth,            //     to get pixels (We don't want to
                    SpriteRectHeight),          //     draw the whole thing)
                Color.White,                    // - The color
                0,                              // - Rotation (none currently)
                Vector2.Zero,                   // - Origin inside the image (top left)
                1.0f,                           // - Scale (100% - no change)
                flipSprite,                     // - Can be used to flip the image
                0);                             // - Layer depth (unused)
        }
        //draws sprite Falling
        private void DrawSpriteFalling(SpriteEffects flipSprite, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                spriteSheet,                    // - The texture to draw
                SCREEN_CENTER,                 // - The location to draw on the screen
                new Rectangle(                  // - The "source" rectangle
                    2 * SpriteRectWidth,    //   - This rectangle specifies
                    SpriteRectOffsetY + (SpriteRectHeight * 2),          //	   where "inside" the texture
                    SpriteRectWidth,            //     to get pixels (We don't want to
                    SpriteRectHeight),          //     draw the whole thing)
                Color.White,                    // - The color
                0,                              // - Rotation (none currently)
                Vector2.Zero,                   // - Origin inside the image (top left)
                1.0f,                           // - Scale (100% - no change)
                flipSprite,                     // - Can be used to flip the image
                0);                             // - Layer depth (unused)
        }


        //draws the sprites idle animation
        private void DrawSpriteIdle(SpriteEffects flipSprite, SpriteBatch spriteBatch)
        {
            if (frame <= 1)
            {
                spriteBatch.Draw(
                    spriteSheet,                                // - The texture to draw
                    SCREEN_CENTER,                             // - The location to draw on the screen
                    new Rectangle(                              // - The "source" rectangle
                        frame * SpriteRectWidth,                //   - This rectangle specifies
                        SpriteRectOffsetY + SpriteRectHeight,   //	   where "inside" the texture
                        SpriteRectWidth,                        //     to get pixels (We don't want to
                        SpriteRectHeight),                      //     draw the whole thing)
                    Color.White,                                // - The color
                    0,                                          // - Rotation (none currently)
                    Vector2.Zero,                               // - Origin inside the image (top left)
                    1.0f,                                       // - Scale (100% - no change)
                    flipSprite,                                 // - Can be used to flip the image
                    0);                                         // - Layer depth (unused)
            }
            else if (frame > 1)
            {
                Vector2 newScreenCenter = new Vector2(SCREEN_CENTER.X, SCREEN_CENTER.Y - 1);
                spriteBatch.Draw(
                spriteSheet,                                // - The texture to draw
                newScreenCenter,                             // - The location to draw on the screen
                new Rectangle(                              // - The "source" rectangle
                    frame * SpriteRectWidth,                //   - This rectangle specifies
                    SpriteRectOffsetY + SpriteRectHeight - 1,   //	   where "inside" the texture
                    SpriteRectWidth,                        //     to get pixels (We don't want to
                    SpriteRectHeight),                      //     draw the whole thing)
                Color.White,                                // - The color
                0,                                          // - Rotation (none currently)
                Vector2.Zero,                               // - Origin inside the image (top left)
                1.0f,                                       // - Scale (100% - no change)
                flipSprite,                                 // - Can be used to flip the image
                0);                                         // - Layer depth (unused)
            }
        }

        // Handles for the Update method || May be able to compress this into a single if rather than a switch
        public void updateGameObjectStates(GameMethodStates gmState)
        {
            KeyboardState kbState = Keyboard.GetState();
            if (gmState == GameMethodStates.Update) // Handles for the Update method || May be able to compress this into a single if rather than a switch
            {
                //switch statement that checks the player state
                previousPlayerState = playerState;
                switch (playerState)
                {
                    case PlayerState.WalkRight:
                        // If the player is pressing the a key...
                        if (kbState.IsKeyDown(Keys.A))
                        {
                            // Set the player's direction to left,
                            // their x velocity to zero, and their
                            // state to PlayerState.WalkLeft
                            player.Direction = -1;
                            playerVelocity.X = 0;
                            playerState = PlayerState.WalkLeft;
                        }
                        // otherwise, if the player presses w...
                        else if (kbState.IsKeyDown(Keys.W) || kbState.IsKeyDown(Keys.Space))
                        {
                            // The player jumps
                            playerState = PlayerState.Jump;
                        }
                        // Otherwise, if the user stops pressing the d key...
                        else if (kbState.IsKeyUp(Keys.D))
                        {
                            // make sure the direction stays "right",
                            // and set the player state to StandRight
                            player.Direction = 1;
                            playerState = PlayerState.StandRight;
                        }
                        // otherwise, if the player is not on the ground...
                        else if (!playerIsGrounded)
                        {
                            // they are falling
                            playerState = PlayerState.Fall;
                        }
                        break;

                    case PlayerState.WalkLeft:
                        // If the player is pressing the d key...
                        if (kbState.IsKeyDown(Keys.D))
                        {
                            // Set the player's direction to right,
                            // their x velocity to zero, and their
                            // state to PlayerState.WalkRight
                            player.Direction = 1;
                            playerVelocity.X = 0;
                            playerState = PlayerState.WalkRight;
                        }
                        // Otherwise, if the player is pressing the w key...
                        else if (kbState.IsKeyDown(Keys.W) || kbState.IsKeyDown(Keys.Space))
                        {
                            // the player jumps
                            playerState = PlayerState.Jump;
                        }
                        // Otherwise, if the player lets go of the a key...
                        else if (kbState.IsKeyUp(Keys.A))
                        {
                            // Set the player's direction to left,
                            // and their state to PlayerState.StandLeft
                            player.Direction = -1;
                            playerState = PlayerState.StandLeft;
                        }
                        // otherwise, if the player is not on the ground...
                        else if (!playerIsGrounded)
                        {
                            // they are falling
                            playerState = PlayerState.Fall;
                        }
                        break;

                    case PlayerState.StandLeft:
                        // The player never has x
                        // velocity while standing
                        playerVelocity.X = 0;

                        // If the player is pressing the a key...
                        if (kbState.IsKeyDown(Keys.A))
                        {
                            // The player walks left
                            player.Direction = -1;
                            playerState = PlayerState.WalkLeft;
                        }
                        // Otherwise, if the player is pressing the d key...
                        else if (kbState.IsKeyDown(Keys.D))
                        {
                            // The player walks right
                            player.Direction = 1;
                            playerState = PlayerState.WalkRight;
                        }
                        // Otherwise, if the player presses w...
                        else if (kbState.IsKeyDown(Keys.W) || kbState.IsKeyDown(Keys.Space))
                        {
                            // The player jumps
                            playerState = PlayerState.Jump;
                        }
                        // otherwise, if the player is not on the ground...
                        else if (!playerIsGrounded)
                        {
                            // they are falling
                            playerState = PlayerState.Fall;
                        }
                        break;

                    case PlayerState.StandRight:
                        // The player never has any 
                        // velocity when standing
                        playerVelocity.X = 0;

                        // If the player is pressing the d key...
                        if (kbState.IsKeyDown(Keys.D))
                        {
                            // The player walks right
                            player.Direction = 1;
                            playerState = PlayerState.WalkRight;
                        }
                        // Otherwise, if the player presses a...
                        else if (kbState.IsKeyDown(Keys.A))
                        {
                            // the player walks left
                            player.Direction = -1;
                            playerState = PlayerState.WalkLeft;
                        }
                        // Otherwise, if the player is pressing the w key, 
                        else if (kbState.IsKeyDown(Keys.W) || kbState.IsKeyDown(Keys.Space))
                        {
                            // the player jumps
                            playerState = PlayerState.Jump;
                        }
                        // otherwise, if the player is not on the ground...
                        else if (!playerIsGrounded)
                        {
                            // they are falling
                            playerState = PlayerState.Fall;
                        }
                        break;

                    case PlayerState.Jump:
                        // The player is no longer grounded
                        playerIsGrounded = false;

                        // Boost the player to a
                        // velocity immediately
                        // if they are standing still
                        if (playerVelocity.Y == 0)
                        {
                            playerVelocity.Y = -5;
                        }
                        // Otherwise, if the player has not reached their jump velocity
                        else if (Math.Abs(playerVelocity.Y) < PhysicsConstants.JUMP_V)
                        {
                            if (this.kbState.IsKeyDown(Keys.W) && this.prevKbState.IsKeyDown(Keys.W))
                            {
                                // Accelerate upwards
                                playerVelocity += PhysicsConstants.JUMP_ACCEL;
                            }
                            else if (!this.prevKbState.IsKeyDown(Keys.W) && !this.kbState.IsKeyDown(Keys.W))
                            {
                                // Accelerate upwards
                                playerVelocity += new Vector2(0, -3f);
                                playerState = PlayerState.Peak;
                            }
                        }
                        // Otherwise...
                        else
                        {
                            // Go to the jump peak
                            playerState = PlayerState.Peak;
                        }
                        break;

                    case PlayerState.Fall:
                        // if the player reaches the ground
                        if (playerIsGrounded)
                        {
                            // Pick the state to be in
                            // based on velocity and direction
                            playerVelocity.X = 0;
                            switch (player.Direction)
                            {
                                // direction is to the right
                                case 1:
                                    if (playerVelocity.X > 0)
                                    {
                                        playerState = PlayerState.WalkRight;
                                    }
                                    else
                                    {
                                        playerState = PlayerState.StandRight;
                                    }
                                    break;
                                // Direction is to the left
                                case -1:
                                    if (playerVelocity.X < 0)
                                    {
                                        playerState = PlayerState.WalkLeft;
                                    }
                                    else
                                    {
                                        playerState = PlayerState.StandLeft;
                                    }
                                    break;
                            }
                        }
                        break;

                    case PlayerState.Peak:
                        // If the player is falling...
                        if (playerVelocity.Y > 0)
                        {
                            // Switch state to falling
                            playerState = PlayerState.Fall;
                        }

                        // If the player hits the ground
                        if (playerIsGrounded)
                        {
                            // Pick the state to be in
                            // based on velocity and direction
                            playerVelocity.X = 0;
                            switch (player.Direction)
                            {
                                case 1:
                                    if (playerVelocity.X > 0)
                                    {
                                        playerState = PlayerState.WalkRight;
                                    }
                                    else
                                    {
                                        playerState = PlayerState.StandRight;
                                    }
                                    break;
                                case -1:
                                    if (playerVelocity.X < 0)
                                    {
                                        playerState = PlayerState.WalkLeft;
                                    }
                                    else
                                    {
                                        playerState = PlayerState.StandLeft;
                                    }
                                    break;
                            }
                        }
                        break;
                }

                // If the time since last drop is
                // above the dropTime, the player
                // is no longer dropping anymore
                if (player_timeSinceDrop >= dropTime)
                {
                    dropping = false;
                }

                // If the player wants to drop
                if (dropping == false && kbState.IsKeyDown(Keys.S) && playerState != PlayerState.Fall)
                {
                    player_timeSinceDrop = 0;
                    dropping = true;
                }

                // If the player is walking but their
                // velocity in the x direction is 0...
                if (playerVelocity.X == 0 &&
                    (playerState == PlayerState.WalkLeft ||
                    playerState == PlayerState.WalkRight))
                {
                    // Add the walk speed to velocity, multiplying direction
                    // to modify walkspeed to the player's current direction
                    playerVelocity += player.Direction * PhysicsConstants.WALK_SPEED;
                }


                switch (playerState)
                {
                    case PlayerState.Fall:
                    case PlayerState.Jump:
                    case PlayerState.Peak:
                        // Allowing the player to change
                        // direction and move mid-air
                        bool moving = false;
                        if (kbState.IsKeyDown(Keys.D))
                        {
                            player.Direction = 1;
                            moving = true;
                        }
                        else if (kbState.IsKeyDown(Keys.A))
                        {
                            player.Direction = -1;
                            moving = true;
                        }
                        else
                        {
                            moving = false;
                            playerVelocity.X = 0;
                        }

                        // If the player has not reached the max velocity
                        // in their current direction, then add velocity
                        if ((player.Direction == 1 && playerVelocity.X < (player.Direction * PhysicsConstants.WALK_SPEED).X ||
                            player.Direction == -1 && playerVelocity.X > (player.Direction * PhysicsConstants.WALK_SPEED).X) &&
                            moving)
                        {
                            playerVelocity += player.Direction * PhysicsConstants.WALK_SPEED;
                        }
                        break;
                }

                // If the player is in the air and have not reached max speed...
                if (!playerIsGrounded && playerVelocity.Y < PhysicsConstants.MAX_VELOCITY.Y)
                {
                    // Add gravity to the player's velocity
                    // so that they fall straight downwards
                    playerVelocity += PhysicsConstants.G;
                }
                // Otherwise if the player is on the ground...
                else if (playerIsGrounded)
                {
                    // The player does not move
                    // in the x or y direction
                    playerVelocity.Y = 0;
                }

                // Player always moves by their velocity
                playerPosition += playerVelocity;

                // Copying, changing, and replacing the 
                // player's position based on velocity
                Rectangle copy = player.Position;
                player.Position = new Rectangle((int)playerPosition.X,
                                                (int)playerPosition.Y,
                                                copy.Width,
                                                copy.Height);
            }
            else if (gmState == GameMethodStates.Draw) // Handles for the Draw method
            {

            }
        }

        /// <summary>
        /// Assigns the player of this StateController to player
        /// </summary>
        /// <param name="player">the player that will be assigned to this StateController</param>
        public void AssignPlayer(Player player)
        {
            this.player = player;

            // Starting the non-int position to the found player's position
            playerPosition = new Vector2(player.Position.X, player.Position.Y);

            player.Direction = 1;
        }

        /// <summary>
        /// assigns the exit in this statecontroller to the one from the levelloader
        /// </summary>
        /// <param name="exit"></param>
        public void AssignExit(LevelExit exit)
        {
            this.exit = exit;
        }

        /// <summary>
        /// Adds elapsed time to player_timeSinceLastProjectile
        /// </summary>
        /// <param name="gameTime"></param>
        public void CheckProjectileTimes(GameTime gameTime)
        {
            // If the time since last shot has not
            // reached the fire rate, add elapsed time
            if (player_timeSinceLastShot < player_fireRate)
            {
                player_timeSinceLastShot += (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
            // Same thing as above for the enemies
            if (enemy_timeSinceLastShot < enemy_fireRate)
            {
                enemy_timeSinceLastShot += (float)gameTime.ElapsedGameTime.TotalSeconds;
            }

            if (player_timeSinceDrop < dropTime)
            {
                player_timeSinceDrop += (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
        }

        /// <summary>
        /// Takes care of projectile motion and gravity
        /// </summary>
        /// <param name="levelLoader"></param>
        public void DoProjectileMotion()
        {
            // if there are projectiles present,
            // move them by their velocity, apply
            // gravity, delete them if they are below
            // the map, and check all collisions
            if (projectiles.Count > 0)
            {
                for (int i = 0; i < projectiles.Count; i++)
                {
                    // Copying, changing, and replacing position
                    Point position = new Point((int)(projectiles[i].Position.X + projectiles[i].Velocity.X),
                                               (int)(projectiles[i].Position.Y + projectiles[i].Velocity.Y));
                    Point size = projectiles[i].Position.Size;
                    projectiles[i].Position = new Rectangle(position, size);

                    // Applying gravity to the projectile
                    projectiles[i].Velocity.Y += PhysicsConstants.G_PROJECTILE.Y;

                    // Deleting the projectile 
                    // if it goes below the map
                    if (projectiles[i].Position.Y > LevelLoader.LowestPosition + SCREEN_CENTER.Y)
                    {
                        projectiles[i].Destroy(projectiles);
                        i--;

                        // This projectile is gone,
                        // so checking for collisions
                        // would lead to an error
                        continue;
                    }

                    //player collision
                    player.CheckCollision(projectiles[i]);

                    // Checking all collisions
                    for (int j = 0; j < LevelLoader.Map.Count; j++)
                    {
                        GameObject collisionToCheck = LevelLoader.Map[j];

                        // if the projectile collides with something, destroy it
                        if (collisionToCheck.CheckCollision(projectiles[i]))
                        {
                            projectiles[i].Destroy(projectiles);
                            i--;

                            // Don't need to check if
                            // this projectile is 
                            // colliding with anything
                            // else
                            j = LevelLoader.Map.Count;
                        }
                    }
                }
            }
        }
        public void UpdateAnimation(GameTime gameTime)
        {
            // Handle animation timing
            // - Add to the time counter
            // - Check if we have enough "time" to advance the frame
            timeCounter += gameTime.ElapsedGameTime.TotalSeconds;
            if (timeCounter >= timePerFrame)
            {
                frame += 1;                     // Adjust the frame

                if (frame > FrameCount-1)   // Check the bounds
                    frame = 0;                  // Back to 1 (since 0 is the "standing" frame)

                timeCounter -= timePerFrame;    // Remove the time we "used"
            }
        }
    }
}