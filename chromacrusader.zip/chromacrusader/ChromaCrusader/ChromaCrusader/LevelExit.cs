﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Inherits from GameObject, allows player to exit the level when enough has been painted
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    public class LevelExit : GameObject
    {
        private bool open;

        //texture for when the level exit opens up
        private Texture2D openedTexture;

        /// <summary>
        /// parameterized constructor that sends info back to the standard GameObject
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public LevelExit(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper, Texture2D openedTexture) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            this.openedTexture = openedTexture;
            open = false;
        }

        /// <summary>
        /// when the door is opened, this is called so that it can be cleared
        /// </summary>
        public void Open()
        {
            open = true;
            Texture = openedTexture;
        }

        /// <summary>
        /// if the object checked is the player, and the exit is open, the level can be ended
        /// </summary>
        /// <param name="check"></param>
        /// <returns></returns>
        public override bool CheckCollision(GameObject check)
        {
            if (check is Player && this.IsActive && check.IsActive && open && Position.Intersects(check.Position))
            {
                return true;
            }
            //if it's not active then it's always false
            else { return false; }
        }
    }
}
