﻿using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Child of GameObject, is Paintable. Environment objects cannot be moved so do not require an override
/// Editors: Fisher Meddaugh
/// </summary>

namespace ChromaCrusader
{
    class Environment : GameObject, IPaintable
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard GameObject
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Environment(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            TouchPlayer += collisionHelper.Paint;
            TouchPlayer += collisionHelper.Counter;
            TouchBullet += collisionHelper.Counter;
        }

    }
}
