﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Helps with methods for the painting event
/// Editors: Fisher Meddaugh, Eric Delmonico
/// </summary>

namespace ChromaCrusader
{

    //delegate for the painting event
    public delegate void CollisionDelegate(GameObject gameObject);

    public class CollisionHelper
    {
        //ints for the number of paintables on map and number painted so far
        private int numberOfPaintables;
        private int numberPainted;

        //player object so it can be killed
        private Player player;

        //exit object so the door is opened
        private LevelExit exit;

        //random object for changing color
        private Random random;

        /// <summary>
        /// The number of paintables on the map
        /// </summary>
        public int NumPaintables
        {
            get { return numberOfPaintables; }
        }

        /// <summary>
        /// The number of objects painted
        /// </summary>
        public int NumPainted
        {
            get { return numberPainted; }
        }

        /// <summary>
        /// constructor sets the number of paintables and the number of ones already painted
        /// </summary>
        public CollisionHelper()
        {
            numberOfPaintables = 0;
            numberPainted = 0;
            random = new Random();
        }

        /// <summary>
        /// sets the player for the collision helper to be the main player
        /// </summary>
        /// <param name="player"></param>
        public void AssignPlayer(Player player)
        {
            this.player = player;
        }

        /// <summary>
        /// sets the exit in this class to the one from the level loader
        /// </summary>
        /// <param name="exit"></param>
        public void AssignExit(LevelExit exit)
        {
            this.exit = exit;
        }

        /// <summary>
        /// Used by mapLoader to increment paintables
        /// </summary>
        public void IncrementPaintables()
        {
            numberOfPaintables++;
        }

        /// <summary>
        /// resets stuff so it doesn't break and either win when you don't do anything or become unwinnable
        /// </summary>
        public void ResetPaint()
        {
            numberOfPaintables = 0;
            numberPainted = 0;
        }

        /// <summary>
        /// increments the number of things that have been painted
        /// used by anything in the environment and paintable enemies
        /// </summary>
        /// <param name="random"></param>
        public void Counter(GameObject gameObject)
        {
            numberPainted++;
            //this SHOULD make it so it only increases once, but I need to get the whole game working to find out
            gameObject.TouchBullet -= Counter;
            gameObject.TouchPlayer -= Counter;
            gameObject.TouchEnemyBullet += UnPaint;

            if((numberOfPaintables*3)/4<=numberPainted)
            {
                exit.Open();
            }
        }

        /// <summary>
        /// paints the object
        /// used by most things to paint them when player touches
        /// </summary>
        /// <param name="random"></param>
        /// <returns></returns>
        public void Paint(GameObject gameObject)
        {
            //randomizes the color
            for(int i = 0;i==0;)
            {
                int r = random.Next(0, 256);
                int g = random.Next(0, 256);
                int b = random.Next(0, 256);
                //only continues if it is bright enough but not too bright
                if(150<r+g+b&&r+g+b<650)
                {
                    i++;
                    gameObject.Color = new Color(r, g, b);
                }
            }

            //so that they don't change colors every frame lol
            if (gameObject is Environment)
            {
                gameObject.TouchPlayer -= Paint;
            }
        }

        /// <summary>
        /// will kill the player
        /// used by enemies, hazards, and bullets
        /// </summary>
        /// <param name="gameObject"></param>
        public void KillPlayer(GameObject gameObject)
        {
            player.IsActive = false;
        }

        /// <summary>
        /// deactivates the object
        /// used by enemies when hit by bullet
        /// </summary>
        /// <param name="gameObject"></param>
        public void Deactivate(GameObject gameObject)
        {
            gameObject.IsActive = false;
        }

        /// <summary>
        /// if an object is already painted, it can be unpainted by enemies
        /// </summary>
        /// <param name="gameObject"></param>
        public void UnPaint(GameObject gameObject)
        {
            //sets color and decreases painted
            gameObject.Color = gameObject.DefaultColor;
            numberPainted--;
            //readds the counter to the object
            gameObject.TouchBullet += Counter;
            gameObject.TouchPlayer += Counter;
            //readds painting to the object when touched
            gameObject.TouchPlayer += Paint;
            //removes this method
            gameObject.TouchEnemyBullet -= UnPaint;
        }
    }
}
