﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Interface that is checked for knowing if something needs painted in the level
/// Editiors: Fisher Meddaugh
/// </summary>

namespace ChromaCrusader
{

    interface IPaintable
    {

    }
}
