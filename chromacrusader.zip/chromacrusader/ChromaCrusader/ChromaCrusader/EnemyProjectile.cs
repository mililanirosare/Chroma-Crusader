﻿using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// enemy projectiles kill the player and move only in one direction
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class EnemyProjectile : Projectile
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard Projectile
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public EnemyProjectile(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper, Vector2 velocity) : base(newTexture, newPosition, newColor, collisionHelper, velocity)
        {
            TouchPlayer += collisionHelper.KillPlayer;
            TouchBullet += collisionHelper.Deactivate;
        }

    }
}
