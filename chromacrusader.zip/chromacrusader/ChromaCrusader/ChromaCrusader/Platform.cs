﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// platforms are... platforms. The player can paint them and walk on them. That's it
/// Editors: Fisher Meddaugh
/// </summary>
namespace ChromaCrusader
{
    class Platform : Environment
    {

        /// <summary>
        /// parameterized constructor that sends info back to the standard Environment
        /// </summary>
        /// <param name="newTexture"></param>
        /// <param name="newPosition"></param>
        public Platform(Texture2D newTexture, Rectangle newPosition, Color newColor, CollisionHelper collisionHelper) : base(newTexture, newPosition, newColor, collisionHelper)
        {
            
        }
    }
}
