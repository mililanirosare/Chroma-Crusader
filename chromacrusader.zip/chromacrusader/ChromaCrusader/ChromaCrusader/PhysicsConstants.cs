﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace ChromaCrusader
{
    static class PhysicsConstants
    {
        public static readonly Vector2 G = new Vector2(0, 1.0f);
        public static readonly Vector2 G_MID_JUMP = new Vector2(0, 0.75f);
        public static readonly Vector2 G_PROJECTILE = new Vector2(0, 1.25f);
        public static readonly Vector2 JUMP_ACCEL = new Vector2(0, -5f);
        public const int JUMP_V = 15;
        public static readonly Vector2 WALK_SPEED = new Vector2(5.0f, 0);
        public static readonly Vector2 MAX_VELOCITY = new Vector2(32, 32); // this should be the standard sprite size
        public const int ENEMY_WALK_SPEED = 5;
    }
}
